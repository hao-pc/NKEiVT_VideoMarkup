import asyncio
from configs.configs import MainConfig
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties

from start import start, test, get_video, qStates

MainConfig: MainConfig = MainConfig("configs/configs_data/main_config_data")

Bot = Bot(
    token=MainConfig.bot_token,
    default=DefaultBotProperties(
        parse_mode="html"
    )
)
Dispatcher: Dispatcher = Dispatcher()

Dispatcher.message.register(start, F.text == "/start")

Dispatcher.callback_query.register(test, F.data == "test")
Dispatcher.message.register(get_video, qStates.get_video)


async def launchBot() -> None:
    try:
        await Dispatcher.start_polling(Bot)
    finally:
        await Bot.session.close()
    return None


async def main() -> None:
    await asyncio.gather(
        launchBot()
    )
    return None

if __name__ == "__main__":
    asyncio.run(main())
