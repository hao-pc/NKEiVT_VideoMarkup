from environs import Env


class MainConfig:
    bot_token: str

    def __init__(self, main_config_data_path: str) -> None:
        Environment = Env()
        Environment.read_env(main_config_data_path)
        self.bot_token = Environment.str("BOT_TOKEN")
