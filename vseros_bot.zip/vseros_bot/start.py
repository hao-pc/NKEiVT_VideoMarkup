from aiogram import Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import ContentType


class qStates(StatesGroup):
    get_video = State()


keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(
                text="Транскрибировать и анализировать тональность",
                callback_data="test"
            )
        ],
        [
            InlineKeyboardButton(
                text="Анализировать аудио",
                callback_data="test"
            )
        ],
        [
            InlineKeyboardButton(
                text="Обнаружить объекты",
                callback_data="test"
            )
        ]
    ]
)


async def start(message: Message, bot: Bot, state: FSMContext) -> None:
    await bot.send_message(
        chat_id=message.from_user.id,
        text="Выберите желаемое действие",
        reply_markup=keyboard
    )
    await bot.delete_message(
        chat_id=message.from_user.id,
        message_id=message.message_id
    )
    await state.clear()
    return None


async def test(callback: CallbackQuery, bot: Bot, state: FSMContext):
    await bot.send_message(
        chat_id=callback.from_user.id,
        text="Отправьте, пожалуйста, мне видео:"
    )
    await state.set_state(qStates.get_video)


async def get_video(message: Message, bot: Bot, state: FSMContext):
    if message.content_type == ContentType.VIDEO:
        await bot.send_message(
            chat_id=message.from_user.id,
            text="Ваше видео получено!"
        )
        await state.clear()
    else:
        await bot.send_message(
            chat_id=message.from_user.id,
            text="Вы не загрузили видео, попробуйте ещё раз..."
        )
        await state.set_state(qStates.get_video)